package com.Disney.DisneyApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisneyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisneyAppApplication.class, args);
	}

}
